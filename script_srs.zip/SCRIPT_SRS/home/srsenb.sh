#!/bin/sh
cpupower frequency-set -g performance
uhd_usrp_probe
srsenb
