#!/bin/sh
cpupower frequency-set -g performance
srsepc
