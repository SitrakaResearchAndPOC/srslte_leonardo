#!/bin/sh
systemctl stop gdm

