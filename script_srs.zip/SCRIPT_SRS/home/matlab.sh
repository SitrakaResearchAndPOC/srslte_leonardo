#!/bin/bash
echo "go on directory matlab"
cd /usr/local/MATLAB/R2018b/bin
./matlab
