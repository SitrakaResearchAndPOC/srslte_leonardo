#!/bin/sh
systemctl start gdm

