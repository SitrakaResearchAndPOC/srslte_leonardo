function hash = getting_key_with_parm(index_in, choice, hash_type,  length_bit)
% eg : hash = getting_key_with_parm(1, 1, 'SHA3-256', 256)
% choice : 1, ..., 8
% hash type : 'SHA3-256'  'SHA3-512' 'SHAKE-256' 'SHAKE-512'
% length_bit : 256 512

matrix = imread('lena.bmp');

block_split = 135;
instability_repeat = 1;

[msg, period] = split_matrix(matrix, index_in, block_split);
% disp('msg');
% disp(msg);
% [A, B] = size(msg);
% disp('hash_type');
% disp(hash_type);
   
hash = ANN_Chaos_SHA3_hash(choice, msg, length_bit, instability_repeat+period, hash_type);
   
% disp('hash');
% disp(hash);
   
end