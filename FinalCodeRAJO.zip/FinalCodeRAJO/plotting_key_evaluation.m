function result_entropy_binary = plotting_key_evaluation(number_key, options_line)
% eg : number_key = 10
% eg : options line is - or :  or -- or  
length_bit = 0;
while ((length_bit ~= 256) && (length_bit ~= 512))
    length_bit = input(num2str('Enter the number of bit of key : 256 or 512  : '));
end

indice_hash = 0;
disp(' ');
while ((indice_hash ~= 1) && (indice_hash ~= 2))
    disp('Please select 1 for SHA3 and 2 for SHAKE ');
    indice_hash = input(num2str('Enter the number of bit of key : 256 or 512  : '));
end

hash_type = '';
if (indice_hash == 1)
    if(length_bit == 256)
        hash_type = 'SHA3-256';
    else 
        hash_type = 'SHA3-512';        
    end
else 
    if(length_bit == 256)
        hash_type = 'SHAKE-256';
    else 
        hash_type = 'SHAKE-512';        
    end    
end
    

result_entropy_binary = zeros(8, number_key);
result_prob_extreme =  zeros(8, number_key);
result_prob_bit_changement =  zeros(8, number_key);
result_prob_proximity =  zeros(8, number_key);
result_correlation =  zeros(8, number_key);

for type = 1:8
    for index = 1:number_key
        key1 = toboolean(getting_key_with_parm(index, type, hash_type, length_bit));
        key2 = toboolean(getting_key_with_parm(index+1, type, hash_type, length_bit));
        result_entropy_binary(type, index) = key_entropy_binary(key1);
        result_prob_extreme(type, index) = key_prob_extreme(key1);
        result_prob_bit_changement(type, index) = key_prob_bit_changement(key1, key2);
        result_prob_proximity(type, index) = key_prob_proximity(key1, key2);
        result_correlation(type, index) = key_correlation(key1, key2);
    end
        
end


% clc
all_type = [0:(number_key-1)];
color(1,:) = [57 106 177]./255;
color(2,:) = [204 37 41]./255;
color(3,:) = [83 81 84]./255;
color(4,:) = [62 150 81]./255;
color(5,:) = [200 200 0]./255;
color(6,:) = [107 76 154]./255;
color(7,:) = [255 128 0]./255;
color(8,:) =  [0 190 190]./255;


for type = 1:8
    grid on;
    hold on;
    plot(all_type, result_entropy_binary(type,:), options_line, 'color', color(type,:), 'LineWidth', 1.5);
    
end
ylabel('Binary entropy');
xlabel('Number of users');
legend('Gingerbreadman map','Henon map','Tinkerbell map','Burgers map','Logistic map','Ricker map', 'Cubic', 'Sine');
title(strcat('Binary Entropy : ', hash_type))


figure
for type = 1:8
    grid on;
    hold on;
    plot(all_type, result_prob_extreme(type,:), options_line, 'color', color(type,:), 'LineWidth', 1.5);
    
end
ylabel('Probability extreme');
xlabel('Number of users');
legend('Gingerbreadman map','Henon map','Tinkerbell map','Burgers map','Logistic map','Ricker map', 'Cubic', 'Sine');
title(strcat('Probability Extreme : ', hash_type))



figure
for type = 1:8
    grid on;
    hold on;
    plot(all_type, result_prob_bit_changement(type,:), options_line, 'color', color(type,:), 'LineWidth', 1.5);
    
end
ylabel('Probrability  of bit changement');
xlabel('Number of users');
legend('Gingerbreadman map','Henon map','Tinkerbell map','Burgers map','Logistic map','Ricker map', 'Cubic', 'Sine');
title(strcat('Probrability  of bit changement : ', hash_type))





figure
for type = 1:8
    grid on;
    hold on;
    plot(all_type, result_prob_proximity(type,:), options_line, 'color', color(type,:), 'LineWidth', 1.5);
    
end
ylabel('Probability of proximity');
xlabel('Number of users');
legend('Gingerbreadman map','Henon map','Tinkerbell map','Burgers map','Logistic map','Ricker map', 'Cubic', 'Sine');
title(strcat('Probability of proximity : ', hash_type))





figure
for type = 1:8
    grid on;
    hold on;
    plot(all_type, result_correlation(type,:), options_line, 'color', color(type,:), 'LineWidth', 1.5);
    
end
ylabel('Correlation');
xlabel('Number of users');
legend('Gingerbreadman map','Henon map','Tinkerbell map','Burgers map','Logistic map','Ricker map', 'Cubic', 'Sine');
title(strcat('Correlation : ', hash_type))


%disp(result_entropy_binary);



end
