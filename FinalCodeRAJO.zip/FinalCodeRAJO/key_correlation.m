function corr = key_correlation(key1, key2)
    corr = coeff_correl(key1, key2);
end