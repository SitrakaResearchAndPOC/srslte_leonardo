function outx=crypter(inp)
%inp=[35 23 37 45 68 25 236 58 59 90]
for i=1:length(inp)
inpx(i,:)=bitget(inp(i),8:-1:1);
end
% generation de la s�quence chaotique -------------------------------------------
l=length(inp);
x(1)=0.75
mu=3.9
for i=2:l
x(i)=mu*x(i-1)*(1-x(i-1));
end
x=uint8(((x-min(x))/max(x))*255);
b=[];
for i=1:l
b(i,:)= bitget(x(i),8:-1:1);
end
temp=0;
outx=zeros(1,length(inp));
% r�seaux -----------------------------------------------------------------
for c=1:length(inp)
for i=1:8
for j=1:8
if (b(c,i)==0)&(i==j)
weight(i,j)=1;
elseif (b(c,i)==1)&(i==j)
weight(i,j)=-1;
elseif i~=j
weight(i,j)=0;
end
end
if (b(c,i)==0)
theta(i)=-1/2;
else theta(i)=1/2;
end
end
for i=1:8
dx(c,i) = hardlim(sum(weight(i,:).*inpx(c,:))+theta(i));
end
for i=1:8
outx(c)=outx(c)+uint8(dx(c,i))*(2^(8-i));
end
end
