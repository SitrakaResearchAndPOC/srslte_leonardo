function plotting_full_matrix_result1()

%choice = 0;
%disp(' ');
%while((choice<1)||(choice > 8))
%    disp('Please select the choice of chaotic map');
%    disp(' 1 : Gingerbreadman map      2 : Henon map');
%    disp(' 3 : Tinkerbell map          4 : Burgers map');
%    disp(' 5 : Logistic map            6 : Ricker map');
%    disp(' 7 : Cubic map               8 : Sine map');
%    choice =  input(num2str('Enter choice between 1 and 8 : '));
%end

matrix = imread('lena.bmp');

[H, W] = size(matrix);

%type = choice
type = 1;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm1 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub1 = ANN_Substitution(double(matrix_perm1), chaotic_sequence);
matrix_sub1 = reshape(matrix_sub1, H,W);
matrix_perm1 = reshape(matrix_perm1, H,W);


type = 2;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm2 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub2 = ANN_Substitution(double(matrix_perm2), chaotic_sequence);
matrix_sub2 = reshape(matrix_sub2, H,W);
matrix_perm2 = reshape(matrix_perm2, H,W);



%imshow(uint8(matrix_sub));    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  PLOTTING MATRIX %%%%%%%%%%%%%%%%%%%%%%%%
imshow(uint8(matrix));
title('original matrix');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  PLOTTING MATRIX PERMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
imshow(uint8(matrix_perm1));
title(' Matrix after Gingerbreadman chaotic permutation');

subplot(4,2,2)
imshow(uint8(matrix_perm2));
title(' Matrix after Henon chaotic permutation');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  PLOTTING MATRIX SUBSTITUTION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
imshow(uint8(matrix_sub1));
title(' Matrix after Gingerbreadman chaotic substitution');

subplot(4,2,2)
imshow(uint8(matrix_sub2));
title(' Matrix after Henon chaotic substitution');




% %%%%%%%%%%%%%%%%%%%%%%%%% PLOTTING HISTOGRAM %%%%%%%%%%%%%%%%%%%%%%%%
figure
imhist(uint8(matrix_perm1(:)));
title(' Original histogram');

%%%%%%%%%%%%%%%%%%%%%%%%%% PLOTTING HISTOGRAM PERMMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
imhist(uint8(matrix_perm1(:)));
title(' Histogram after Gingerbreadman chaotic permutation');

subplot(4,2,2)
imhist(uint8(matrix_perm2(:)));
title(' Histogram after Henon chaotic permutation');


%%%%%%%%%%%%%%%%%%%%%%%%%% PLOTTING HISTOGRAM SUBSTUTTION %%%%%%%%%%%%%%%%%%%%%%%%
disp('sub');
figure
subplot(4,2,1)
imhist(uint8(matrix_sub1(:)));
title(' Histogram after Gingerbreadman chaotic substitution');

subplot(4,2,2)
imhist(uint8(matrix_sub2(:)));
title(' Histogram after Henon chaotic substitution');

%imhist(m(:))





end