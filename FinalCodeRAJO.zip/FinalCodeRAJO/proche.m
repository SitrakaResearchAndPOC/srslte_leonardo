
function res = proche(cle, bit)
% L = length(cle);
L = 2;
 if(bit == 0)
     res = true;
     for i = 1:L/2
         if(cle(i) == 1)
             res = false;
         end
     end  
 else
     res = false;
     for i = 1:L/2
         if(cle(i) == 1)
             res = true;
         end
     end   
 end
 
end
