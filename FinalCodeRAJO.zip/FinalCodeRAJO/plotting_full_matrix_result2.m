function plotting_full_matrix_result2()
% Result 2 Plot : Correlation, PSNR, EQM, SSIM, UACI, NPCR
matrix = imread('lena.bmp');
[H, W] = size(matrix);


%disp(coeff_correl(matrix, matrix_perm1));

result_coeff_correl = 0;
result_psnr = 0;
result_eqm = 0;
result_ssim = 0;
result_uaci = 0;
result_npcr = 0;


ligne = 1;
for type = 1 : 8
    chaotic_sequence = generate_chaotique(W*H, type);
    matrix_perm =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
    matrix_sub = ANN_Substitution(double(matrix_perm), chaotic_sequence);
    matrix_sub = reshape(matrix_sub, H,W);    
    matrix_perm = reshape(matrix_perm, H,W);

    result_coeff_correl(ligne,1) =  abs(coeff_correl(matrix, matrix_perm));
    result_coeff_correl(ligne,2) =  abs(coeff_correl(matrix, matrix_sub));

    result_psnr(ligne,1) =  abs(psnr(matrix, matrix_perm));
    result_psnr(ligne,2) =  abs(psnr(matrix, matrix_sub));
    
    result_eqm(ligne,1) =  abs(eqm(matrix, matrix_perm));
    result_eqm(ligne,2) =  abs(eqm(matrix, matrix_sub));
    
    
    [ssim1, ssimMap] = ssim(matrix,matrix_perm, [0.05 0.05], ones(8), 255);
    [ssim2, ssimMap] = ssim(matrix,matrix_sub, [0.05 0.05], ones(8), 255);
    
    result_ssim(ligne,1) =  abs(ssim1);
    result_ssim(ligne,2) =  abs(ssim2);
    
    [npcr1,uaci1]=NPCR_UCAI(matrix,matrix_perm);
    [npcr2,uaci2]=NPCR_UCAI(matrix,matrix_sub);

    result_npcr(ligne,1) =  abs(npcr1);
    result_npcr(ligne,2) =  abs(npcr2);
    
    result_uaci(ligne,1) =  abs(uaci1);
    result_uaci(ligne,2) =  abs(uaci2);
    
    
    ligne = ligne+1;
end
    
disp(result_coeff_correl);


%figure
y = result_coeff_correl
b = bar(y,'FaceColor','flat');
for k = 1:size(y,2)
    b(k).CData = k;
end
title('Correlation for all chaotic type between original-permute and original-substitution');

figure
y = result_psnr
b = bar(y,'FaceColor','flat');
for k = 1:size(y,2)
    b(k).CData = k;
end
title('PSNR for all chaotic type between original-permute and original-substitution');


figure
y = result_eqm
b = bar(y,'FaceColor','flat');
for k = 1:size(y,2)
    b(k).CData = k;
end
title('MSE for all chaotic type between original-permute and original-substitution');


figure
y = result_ssim
b = bar(y,'FaceColor','flat');
for k = 1:size(y,2)
    b(k).CData = k;
end
title('SSIM for all chaotic type between original-permute and original-substitution');


figure
y = result_npcr
b = bar(y,'FaceColor','flat');
for k = 1:size(y,2)
    b(k).CData = k;
end
title('NPCR for all chaotic type between original-permute and original-substitution');

figure
y = result_uaci
b = bar(y,'FaceColor','flat');
for k = 1:size(y,2)
    b(k).CData = k;
end
title('UACI for all chaotic type between original-permute and original-substitution');


end
