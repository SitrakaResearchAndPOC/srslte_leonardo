Just launch 
>> getting_key()

For plotting key with index_in = 1 for 256 bits
>> plotting_key256(1)


For plotting key with index_in = 1 for 512 bits
>> plotting_key512(1)


Before imshow, use conversion uint8

>> testing_inversibility_chaotic_ANN_Substitution
>> testing_inversibility_chaotic_HamiltonianPermutation
>> plotting_full_matrix_result1
>> plotting_full_matrix_result2

For plotting key evaluation : 
>> plotting_key_evaluation(10, '-')

or
>> plotting_key_evaluation(10, ':')

or
>> plotting_key_evaluation(10, '--')


%% Indice for key evaluation
key_entropy_binary(toboolean(getting_key_with_parm(1, 1, 'SHA3-256', 256)))
key_prob_extreme(toboolean(getting_key_with_parm(1, 1, 'SHA3-256', 256)))
key_prob_bit_changement(toboolean(getting_key_with_parm(1, 1, 'SHA3-256', 256)), toboolean(getting_key_with_parm(2, 1, 'SHA3-256', 256)))
key_prob_proximity(toboolean(getting_key_with_parm(1, 1, 'SHA3-256', 256)), toboolean(getting_key_with_parm(2, 1, 'SHA3-256', 256)))
key_correlation(toboolean(getting_key_with_parm(1, 1, 'SHA3-512', 512)), toboolean(getting_key_with_parm(2, 1, 'SHA3-512', 512)))
