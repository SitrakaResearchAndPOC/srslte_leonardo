function plotting_full_matrix_result1()

%choice = 0;
%disp(' ');
%while((choice<1)||(choice > 8))
%    disp('Please select the choice of chaotic map');
%    disp(' 1 : Gingerbreadman map      2 : Henon map');
%    disp(' 3 : Tinkerbell map          4 : Burgers map');
%    disp(' 5 : Logistic map            6 : Ricker map');
%    disp(' 7 : Cubic map               8 : Sine map');
%    choice =  input(num2str('Enter choice between 1 and 8 : '));
%end

matrix = imread('lena.bmp');

[H, W] = size(matrix);

%type = choice
type = 1;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm1 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub1 = ANN_Substitution(double(matrix_perm1), chaotic_sequence);
matrix_sub1 = reshape(matrix_sub1, H,W);
matrix_perm1 = reshape(matrix_perm1, H,W);


type = 2;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm2 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub2 = ANN_Substitution(double(matrix_perm2), chaotic_sequence);
matrix_sub2 = reshape(matrix_sub2, H,W);
matrix_perm2 = reshape(matrix_perm2, H,W);



type = 3;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm3 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub3 = ANN_Substitution(double(matrix_perm3), chaotic_sequence);
matrix_sub3 = reshape(matrix_sub3, H,W);
matrix_perm3 = reshape(matrix_perm3, H,W);


type = 4;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm4 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub4 = ANN_Substitution(double(matrix_perm4), chaotic_sequence);
matrix_sub4 = reshape(matrix_sub4, H,W);
matrix_perm4 = reshape(matrix_perm4, H,W);



type = 5;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm5 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub5 = ANN_Substitution(double(matrix_perm5), chaotic_sequence);
matrix_sub5 = reshape(matrix_sub5, H,W);
matrix_perm5 = reshape(matrix_perm5, H,W);


type = 6;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm6 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub6 = ANN_Substitution(double(matrix_perm6), chaotic_sequence);
matrix_sub6 = reshape(matrix_sub6, H,W);
matrix_perm6 = reshape(matrix_perm6, H,W);


type = 7;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm7 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub7 = ANN_Substitution(double(matrix_perm7), chaotic_sequence);
matrix_sub7 = reshape(matrix_sub7, H,W);
matrix_perm7 = reshape(matrix_perm7, H,W);

type = 8;
chaotic_sequence = generate_chaotique(W*H, type);
matrix_perm8 =  HamiltonianPermutation(matrix(:)', chaotic_sequence);
matrix_sub8 = ANN_Substitution(double(matrix_perm8), chaotic_sequence);
matrix_sub8 = reshape(matrix_sub8, H,W);
matrix_perm8 = reshape(matrix_perm8, H,W);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  PLOTTING MATRIX %%%%%%%%%%%%%%%%%%%%%%%%
imshow(uint8(matrix));
title('original matrix');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  PLOTTING MATRIX PERMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
imshow(uint8(matrix_perm1));
title(' Matrix after Gingerbreadman chaotic permutation');

subplot(4,2,2)
imshow(uint8(matrix_perm2));
title(' Matrix after Henon chaotic permutation');

subplot(4,2,3)
imshow(uint8(matrix_perm3));
title(' Matrix after Tinkerbell chaotic permutation');

subplot(4,2,4)
imshow(uint8(matrix_perm4));
title(' Matrix after Burgers chaotic permutation');

subplot(4,2,5)
imshow(uint8(matrix_perm5));
title(' Matrix after Logistic chaotic permutation');


subplot(4,2,6)
imshow(uint8(matrix_perm6));
title(' Matrix after Ricker chaotic permutation');

subplot(4,2,7)
imshow(uint8(matrix_perm7));
title(' Matrix after Cubic chaotic permutation');

subplot(4,2,8)
imshow(uint8(matrix_perm8));
title(' Matrix after Sine chaotic permutation');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  PLOTTING MATRIX SUBSTITUTION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
imshow(uint8(matrix_sub1));
title(' Matrix after Gingerbreadman chaotic substitution');

subplot(4,2,2)
imshow(uint8(matrix_sub2));
title(' Matrix after Henon chaotic substitution');


subplot(4,2,3)
imshow(uint8(matrix_sub3));
title(' Matrix after Tinkerbell chaotic substitution');


subplot(4,2,4)
imshow(uint8(matrix_sub4));
title(' Matrix after Burgers chaotic substitution');

subplot(4,2,5)
imshow(uint8(matrix_sub5));
title(' Matrix after Logistic chaotic substitution');

subplot(4,2,6)
imshow(uint8(matrix_sub6));
title(' Matrix after Ricker chaotic substitution');


subplot(4,2,7)
imshow(uint8(matrix_sub7));
title(' Matrix after Cubic chaotic substitution');


subplot(4,2,8)
imshow(uint8(matrix_sub8));
title(' Matrix after Sine chaotic substitution');









% %%%%%%%%%%%%%%%%%%%%%%%%% PLOTTING HISTOGRAM %%%%%%%%%%%%%%%%%%%%%%%%
figure
imhist(uint8(matrix_perm1(:)));
title(' Original histogram');

%%%%%%%%%%%%%%%%%%%%%%%%%% PLOTTING HISTOGRAM PERMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
imhist(uint8(matrix_perm1(:)));
title(' Histogram after Gingerbreadman chaotic permutation');

subplot(4,2,2)
imhist(uint8(matrix_perm2(:)));
title(' Histogram after Henon chaotic permutation');


subplot(4,2,3)
imhist(uint8(matrix_perm3(:)));
title(' Histogram after Tinkerbell chaotic permutation');


subplot(4,2,4)
imhist(uint8(matrix_perm4(:)));
title(' Histogram after Burgers chaotic permutation');

subplot(4,2,5)
imhist(uint8(matrix_perm5(:)));
title(' Histogram after Logistic chaotic permutation');

subplot(4,2,6)
imhist(uint8(matrix_perm6(:)));
title(' Histogram after Ricker chaotic permutation');

subplot(4,2,7)
imhist(uint8(matrix_perm7(:)));
title(' Histogram after Cubic chaotic permutation');

subplot(4,2,8)
imhist(uint8(matrix_perm8(:)));
title(' Histogram after Sine chaotic permutation');


%%%%%%%%%%%%%%%%%%%%%%%%%% PLOTTING HISTOGRAM SUBSTUTTION %%%%%%%%%%%%%%%%%%%%%%%%
disp('sub');
figure
subplot(4,2,1)
imhist(uint8(matrix_sub1(:)));
title(' Histogram after Gingerbreadman chaotic substitution');

subplot(4,2,2)
imhist(uint8(matrix_sub2(:)));
title(' Histogram after Henon chaotic substitution');


subplot(4,2,3)
imhist(uint8(matrix_sub3(:)));
title(' Histogram after Tinkerbell chaotic substitution');

subplot(4,2,4)
imhist(uint8(matrix_sub4(:)));
title(' Histogram after  Burgers chaotic substitution');

subplot(4,2,5)
imhist(uint8(matrix_sub5(:)));
title(' Histogram after Logistic chaotic substitution');

subplot(4,2,6)
imhist(uint8(matrix_sub6(:)));
title(' Histogram after Ricker chaotic substitution');

subplot(4,2,7)
imhist(uint8(matrix_sub7(:)));
title(' Histogram after Cubic chaotic substitution');


subplot(4,2,8)
imhist(uint8(matrix_sub8(:)));
title(' Histogram after Sine chaotic substitution');


% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION VERTICAL %%%%%%%%%%%%%%%%%%%%%%%%
figure
distributionVertical(uint8(matrix));
title(' Vertical Distribution of Original matrix');

% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION VERTICAL OF PERMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
distributionVertical(uint8(matrix_perm1));
title('Vertical Distribution Gingerbreadman chaotic after permutation ');

subplot(4,2,2)
distributionVertical(uint8(matrix_perm2));
title('Vertical Distribution Henon chaotic after permutation ');

subplot(4,2,3)
distributionVertical(uint8(matrix_perm3));
title('Vertical Distribution TinkerBell chaotic after permutation ');


subplot(4,2,4)
distributionVertical(uint8(matrix_perm4));
title('Vertical Distribution Burgers chaotic after permutation ');


subplot(4,2,5)
distributionVertical(uint8(matrix_perm5));
title('Vertical Distribution Logistic chaotic after permutation ');


subplot(4,2,6)
distributionVertical(uint8(matrix_perm6));
title('Vertical Distribution Ricker chaotic after permutation ');

subplot(4,2,7)
distributionVertical(uint8(matrix_perm7));
title('Vertical Distribution Cubic chaotic after permutation ');

subplot(4,2,8)
distributionVertical(uint8(matrix_perm8));
title('Vertical Distribution Sine chaotic after permutation ');



% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION VERTICAL OF SUBSTITUTION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
distributionVertical(uint8(matrix_sub1));
title('Vertical Distribution Gingerbreadman chaotic after substitution ');

subplot(4,2,2)
distributionVertical(uint8(matrix_sub2));
title('Vertical Distribution Henon chaotic after substitution ');

subplot(4,2,3)
distributionVertical(uint8(matrix_sub3));
title('Vertical Distribution TinkerBell chaotic after substitution ');


subplot(4,2,4)
distributionVertical(uint8(matrix_sub4));
title('Vertical Distribution Burgers chaotic after substitution  ');


subplot(4,2,5)
distributionVertical(uint8(matrix_sub5));
title('Vertical Distribution Logistic chaotic after substitution  ');


subplot(4,2,6)
distributionVertical(uint8(matrix_sub6));
title('Vertical Distribution Ricker chaotic after substitution  ');

subplot(4,2,7)
distributionVertical(uint8(matrix_sub7));
title('Vertical Distribution Cubic chaotic after substitution  ');

subplot(4,2,8)
distributionVertical(uint8(matrix_sub8));
title('Vertical Distribution Sine chaotic after substitution  ');



% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION HORIZONTAL %%%%%%%%%%%%%%%%%%%%%%%%
figure
distributionHorizontal(uint8(matrix));
title('Horizontal Distribution of Original matrix');

% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION HORIZONTAL OF PERMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
distributionHorizontal(uint8(matrix_perm1));
title('Horizontal Distribution Gingerbreadman chaotic after permutation ');

subplot(4,2,2)
distributionHorizontal(uint8(matrix_perm2));
title('Horizontal Distribution Henon chaotic after permutation ');

subplot(4,2,3)
distributionHorizontal(uint8(matrix_perm3));
title('Horizontal Distribution TinkerBell chaotic after permutation ');


subplot(4,2,4)
distributionHorizontal(uint8(matrix_perm4));
title('Horizontal Distribution Burgers chaotic after permutation ');


subplot(4,2,5)
distributionHorizontal(uint8(matrix_perm5));
title('Horizontal Distribution Logistic chaotic after permutation ');


subplot(4,2,6)
distributionHorizontal(uint8(matrix_perm6));
title('Horizontal Distribution Ricker chaotic after permutation ');

subplot(4,2,7)
distributionHorizontal(uint8(matrix_perm7));
title('Horizontal Distribution Cubic chaotic after permutation ');

subplot(4,2,8)
distributionHorizontal(uint8(matrix_perm8));
title('Horizontal Distribution Sine chaotic after permutation ');



% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION HORIZONTAL OF SUBSTITUTION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
distributionHorizontal(uint8(matrix_sub1));
title('Horizontal Distribution Gingerbreadman chaotic after substitution ');

subplot(4,2,2)
distributionHorizontal(uint8(matrix_sub2));
title('Horizontal Distribution Henon chaotic after substitution ');

subplot(4,2,3)
distributionHorizontal(uint8(matrix_sub3));
title('Horizontal Distribution TinkerBell chaotic after substitution ');


subplot(4,2,4)
distributionHorizontal(uint8(matrix_sub4));
title('Horizontal Distribution Burgers chaotic after substitution  ');


subplot(4,2,5)
distributionHorizontal(uint8(matrix_sub5));
title('Horizontal Distribution Logistic chaotic after substitution  ');


subplot(4,2,6)
distributionHorizontal(uint8(matrix_sub6));
title('Horizontal Distribution Ricker chaotic after substitution  ');

subplot(4,2,7)
distributionHorizontal(uint8(matrix_sub7));
title('Horizontal Distribution Cubic chaotic after substitution  ');

subplot(4,2,8)
distributionHorizontal(uint8(matrix_sub8));
title('Horizontal Distribution Sine chaotic after substitution  ');



% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION DIAGONAL %%%%%%%%%%%%%%%%%%%%%%%%
figure
distributionDiagonal(uint8(matrix));
title('Diagonal Distribution of Original matrix');

% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION Diagonal OF PERMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
distributionDiagonal(uint8(matrix_perm1));
title('Diagonal Distribution Gingerbreadman chaotic after permutation ');

subplot(4,2,2)
distributionDiagonal(uint8(matrix_perm2));
title('Diagonal Distribution Henon chaotic after permutation ');

subplot(4,2,3)
distributionDiagonal(uint8(matrix_perm3));
title('Diagonal Distribution TinkerBell chaotic after permutation ');


subplot(4,2,4)
distributionDiagonal(uint8(matrix_perm4));
title('Diagonal Distribution Burgers chaotic after permutation ');


subplot(4,2,5)
distributionDiagonal(uint8(matrix_perm5));
title('Diagonal Distribution Logistic chaotic after permutation ');


subplot(4,2,6)
distributionDiagonal(uint8(matrix_perm6));
title('Diagonal Distribution Ricker chaotic after permutation ');

subplot(4,2,7)
distributionDiagonal(uint8(matrix_perm7));
title('Diagonal Distribution Cubic chaotic after permutation ');

subplot(4,2,8)
distributionDiagonal(uint8(matrix_perm8));
title('Diagonal Distribution Sine chaotic after permutation ');



% %%%%%%%%%%%%%%%%%%%%%%%%% DISTRIBUTION Diagonal OF SUBSTITUTION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
distributionDiagonal(uint8(matrix_sub1));
title('Diagonal Distribution Gingerbreadman chaotic after substitution ');

subplot(4,2,2)
distributionDiagonal(uint8(matrix_sub2));
title('Diagonal Distribution Henon chaotic after substitution ');

subplot(4,2,3)
distributionDiagonal(uint8(matrix_sub3));
title('Diagonal Distribution TinkerBell chaotic after substitution ');


subplot(4,2,4)
distributionDiagonal(uint8(matrix_sub4));
title('Diagonal Distribution Burgers chaotic after substitution  ');


subplot(4,2,5)
distributionDiagonal(uint8(matrix_sub5));
title('Diagonal Distribution Logistic chaotic after substitution  ');


subplot(4,2,6)
distributionDiagonal(uint8(matrix_sub6));
title('Diagonal Distribution Ricker chaotic after substitution  ');

subplot(4,2,7)
distributionDiagonal(uint8(matrix_sub7));
title('Diagonal Distribution Cubic chaotic after substitution  ');

subplot(4,2,8)
distributionDiagonal(uint8(matrix_sub8));
title('Diagonal Distribution Sine chaotic after substitution  ');






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  PLOTTING LINEAR SCATT PERMUTATION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
linear_scatt(uint8(matrix), uint8(matrix_perm1));
title(' Matrix linear relation after Gingerbreadman chaotic permutation');

subplot(4,2,2)
linear_scatt(uint8(matrix), uint8(matrix_perm2));
title(' Matrix linear relation after Henon chaotic permutation');

subplot(4,2,3)
linear_scatt(uint8(matrix), uint8(matrix_perm3));
title(' Matrix linear relation after Tinkerbell chaotic permutation');

subplot(4,2,4)
linear_scatt(uint8(matrix), uint8(matrix_perm4));
title(' Matrix linear relation after Burgers chaotic permutation');

subplot(4,2,5)
linear_scatt(uint8(matrix), uint8(matrix_perm5));
title(' Matrix linear relation after Logistic chaotic permutation');


subplot(4,2,6)
linear_scatt(uint8(matrix), uint8(matrix_perm6));
title(' Matrix linear relation after Ricker chaotic permutation');

subplot(4,2,7)
linear_scatt(uint8(matrix), uint8(matrix_perm7));
title(' Matrix linear relation after Cubic chaotic permutation');

subplot(4,2,8)
linear_scatt(uint8(matrix), uint8(matrix_perm8));
title(' Matrix linear relation after Sine chaotic permutation');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  LINEAR SCATT SUBSTITUTION %%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(4,2,1)
linear_scatt(uint8(matrix), uint8(matrix_sub1));
title(' Matrix linear relation after Gingerbreadman chaotic substitution');

subplot(4,2,2)
linear_scatt(uint8(matrix), uint8(matrix_sub2));
title(' Matrix linear relation after Henon chaotic substitution');

subplot(4,2,3)
linear_scatt(uint8(matrix), uint8(matrix_sub3));
title(' Matrix linear relation after Tinkerbell chaotic substitution');

subplot(4,2,4)
linear_scatt(uint8(matrix), uint8(matrix_sub4));
title(' Matrix linear relation after Burgers chaotic substitution');

subplot(4,2,5)
linear_scatt(uint8(matrix), uint8(matrix_sub5));
title(' Matrix linear relation after Logistic chaotic substitution');


subplot(4,2,6)
linear_scatt(uint8(matrix), uint8(matrix_sub6));
title(' Matrix linear relation after Ricker chaotic substitution');

subplot(4,2,7)
linear_scatt(uint8(matrix), uint8(matrix_sub7));
title(' Matrix linear relation after Cubic chaotic substitution');

subplot(4,2,8)
linear_scatt(uint8(matrix), uint8(matrix_sub8));
title(' Matrix linear relation after Sine chaotic substitution');


end