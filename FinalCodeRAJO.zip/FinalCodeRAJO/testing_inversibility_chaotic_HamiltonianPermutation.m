function testing_inversibility_chaotic_HamiltonianPermutation()
choice = 0;
disp(' ');
while((choice<1)||(choice > 8))
    disp('Please select the choice of chaotic map');
    disp(' 1 : Gingerbreadman map      2 : Henon map');
    disp(' 3 : Tinkerbell map          4 : Burgers map');
    disp(' 5 : Logistic map            6 : Ricker map');
    disp(' 7 : Cubic map               8 : Sine map');
    choice =  input(num2str('Enter choice between 1 and 8 : '));
end
matrix = imread('lena.bmp');
[H, W] = size(matrix);

type = choice

imshow(uint8(matrix));
title('matrix original before permutation');

chaotic_sequence = generate_chaotique(W*H, choice);
[H, W] = size(matrix);
matrix_perm = HamiltonianPermutation(matrix(:)', chaotic_sequence);

figure 
imshow(uint8(reshape(matrix_perm, H, W)));
title('matrix with permutation');

matrix_rec = HamiltonianPermutation_inverse(double(matrix_perm(:)'), chaotic_sequence);
figure
imshow(uint8(reshape(matrix_rec, H, W)))
title('matrix recover after permutation inverse');

end
