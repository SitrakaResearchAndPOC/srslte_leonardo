function hash = ANN_Chaos_SHA3_hash(type, inp, length_bit, repeat,hash_type)
    %inp=[35 23 37 45 68 25 236 58 59 90];
    [H, W] = size(inp);
    inp_out = inp;
    %disp('input_put sequence');
    %disp(inp);

    chaotic_sequence = generate_chaotique(W*H, type);
    for(r = 1:repeat)
        inp_perm =  HamiltonianPermutation(inp, chaotic_sequence);
        inp_out = ANN_Substitution(double(inp_perm), chaotic_sequence);
        inp = inp_out;
    end
    %disp('out_put sequence');
    %disp(inp_out);

	%disp('length_bit');
	%disp(length_bit);
	%disp('hash_type');
    %disp(hash_type);
	hash = SHA3_hex(inp_out, hash_type, length_bit);
end