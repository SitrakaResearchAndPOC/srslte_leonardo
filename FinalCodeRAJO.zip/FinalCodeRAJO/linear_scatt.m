function linear_scatt(X, Y)
Rx=X(:,:,1);

Ry=Y(:,:,1);
scatter(Rx(:),Ry(:));

end