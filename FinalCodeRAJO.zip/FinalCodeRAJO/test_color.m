function test_color()

%% https://fanwangecon.github.io/M4Econ/graph/tools/fs_color.html




close all
blue = [57 106 177]./255;
red = [204 37 41]./255;
black = [83 81 84]./255;
green = [62 150 81]./255;
yellow = [200 200 0]./255;
purple = [107 76 154]./255;
orange = [255 128 0]./255;
bluelight = [0 190 190]./255;


cl_colors = {blue, red, black, ...
             green, yellow, purple, orange, bluelight};
cl_str_clr_names = ["blue", "red", "black", "green", "yellow", "purple", "orange", bluelight];
for it_color=1:length(cl_colors)
    
    figure();
    x = [0 1 1 0];
    y = [0 0 1 1];
    fill(x, y, cl_colors{it_color});
    st_text = [cl_str_clr_names(it_color) num2str(round(cl_colors{it_color}*255))];
    hText = text(.10,.55, st_text);
    hText.Color = 'white';
    hText.FontSize = 30; 
    snapnow;
    
end





end