function plotting_key256(index_in)
%index_in = 1

% PERMUTATION PLOT
length_bit = 256;
nb_bit = length_bit;
hash_type = 'SHA3-256';

matrix = imread('lena.bmp');
block_split = 135;
instability_repeat = 1;

[msg, period] = split_matrix(matrix, index_in, block_split);


figure


hash = ANN_Chaos_SHA3_hash(1, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,1)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Gingerbreadman map and SHA3-256');



hash = ANN_Chaos_SHA3_hash(2, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,2)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Henon map and SHA3-256');

hash = ANN_Chaos_SHA3_hash(3, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,3)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Tinkerbell map and SHA3-256');



hash = ANN_Chaos_SHA3_hash(4, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,4)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Burgers map and SHA3-256');



hash = ANN_Chaos_SHA3_hash(5, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,5)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Logistic map and SHA3-256');



hash = ANN_Chaos_SHA3_hash(6, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,6)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Ricker map and SHA3-256');


hash = ANN_Chaos_SHA3_hash(7, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,7)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Cubic map  and SHA3-256');


hash = ANN_Chaos_SHA3_hash(8, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,8);
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Sine map  and SHA3-256');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% PERMUTATION PLOT
length_bit = 256;
nb_bit = length_bit;
hash_type = 'SHAKE-256';

matrix = imread('lena.bmp');
block_split = 135;
instability_repeat = 1;

[msg, period] = split_matrix(matrix, index_in, block_split);


figure


hash = ANN_Chaos_SHA3_hash(1, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,1)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Gingerbreadman map and SHAKE-256');



hash = ANN_Chaos_SHA3_hash(2, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,2)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Henon map and SHAKE-256');

hash = ANN_Chaos_SHA3_hash(3, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,3)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Tinkerbell map and SHAKE-256');



hash = ANN_Chaos_SHA3_hash(4, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,4)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Burgers map and SHAKE-256');



hash = ANN_Chaos_SHA3_hash(5, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,5)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Logistic map and SHAKE-256');



hash = ANN_Chaos_SHA3_hash(6, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,6)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Ricker map and SHAKE-256');


hash = ANN_Chaos_SHA3_hash(7, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,7)
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Cubic map  and SHAKE-256');


hash = ANN_Chaos_SHA3_hash(8, msg, length_bit, instability_repeat+period, hash_type);
binhash = toboolean(hash);
%disp(binhash);
subplot(4,2,8);
stairs(binhash);
ylim([0 1.2]);
xlim([0 nb_bit+1]);
title(' Sine map  and SHAKE-256');


end