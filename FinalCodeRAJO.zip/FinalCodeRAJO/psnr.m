function res = psnr(I,I1)
mse = eqm(I,I1);
res = 10*log10(255^2/mse);