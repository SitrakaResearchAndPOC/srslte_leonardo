function [axisf, ordf] = histo_graph(img)

axis = zeros(1,256);
ord = zeros(1,256);

[W, H] = size(img);
indice = 0;
for i=1:256
    axis(i) = i-1;
end


for i=1:W
    for j=1:H
        indice = img(i,j)+1;
        ord(indice) = ord(indice)+1;        
    end
end
%traiter R
nb = 0;
for i=1:256
    if(ord(i) ~= 0)
        nb = nb+1;
    end
end
axisf = zeros(1, nb);
ordf = zeros(1, nb);

j = 1;
for i=1:256
    if(ord(i) ~= 0)
        axisf(j) = axis(i);
        ordf(j) = ord(i);
        j = j+1;
    end        
end

end