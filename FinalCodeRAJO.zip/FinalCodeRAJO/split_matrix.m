function [msg, period] = split_matrix(matrix, index_in, block_split)
    index_in = index_in -1;
    [H, W] = size(matrix); % needed for linearized the matrix
                                
    number_block_split = floor(((W*H)/block_split));

    period = 0;
    if(index_in >=  number_block_split)
        period = floor(index_in/number_block_split);
        index_in = mod(index_in,  number_block_split);
    end
    
    msg = zeros(1,block_split); 
    index_msg = 1;
    for i = index_in+1: index_in + block_split
        % translate to index
        indexY = mod(i-1,W);
        indexX = floor((i-1)/W);
                                
        msg(index_msg) = matrix(indexX+1, indexY+1);
        index_msg = index_msg+1;
    end
    

end