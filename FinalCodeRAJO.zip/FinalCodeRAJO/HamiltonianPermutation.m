%code by sitraka 18/03/2024
function res = HamiltonianPermutation(a, matrix_r)
   % a = [1 2 3 4;5 6 7 8; 9 10 11 12;13 14 15 16;17 18 19 20;21 22 23 24]
    res = a;
   % b = [1 2 3 4 5 6;7 8 9 10 11 12;13 14 15 16 17 18;19 20 21 22 23 24]
   %  d = [1 2 3 4 5;6 7 8 9 10;11 12 13 14 15;16 17 18 19 20;21 22 23 24 25]
   [H, W] = size(a);
   matrix_r = matrix_r';
   %{
   disp(W);
   disp(H);
   %}
   listpath = (-1)*ones(1,W*H);
   selectedpath = (-1)*ones(1,W*H);
   
   % attracteur
   % xgin = (-1)*ones(1,W*H);
   % ygin = (-1)*ones(1,W*H);

   % xgin=0.5;
   % ygin=3.7;
   % for k = 2:W*H
   %         xgin(k,1)=1+abs(xgin(k-1,1))-ygin(k-1,1);
   %         ygin(k,1)=xgin(k-1,1);
   % end        
   % disp('xgin ygin');
   % disp(xgin);
   % disp(ygin);
   
   % matrix_r = (xgin+ygin);
   % disp('matrix_r');
   % disp(matrix_r);
   
   for i = 1:W*H
        selectedpath(i) = i; 
   end    
   %{
   disp('selected path initialization');   
   disp(selectedpath);
   %}
   max = W*H;
   min = 1;
   
   
   k = 1;
   for i = W:-1:1
       for j = H:-1:1
            % selected hamiltonian path by random number between min and
            % max
            
            
            % r = floor((max-min).*rand(1,1) + min);
            pourcentage = abs(floor(matrix_r(k,1))-matrix_r(k,1));
            k = k+1;

            r = floor((max-min).*pourcentage + min);
            
            %{
            disp('random r');
            disp(r);
            %}
            
            listpath(max) = selectedpath(r);
            max = max-1;            
            for k= r:1:max
                selectedpath(k) = selectedpath(k+1);
            end
           %{ 
           disp('selected path');   
           disp(selectedpath);

           
           disp('list path');   
           disp(listpath);
           % delete num2str for matlab 2020
           demand = input(num2str("continue or not : "));
           %}
           
       end
   end

   
   % for matlab , we need to inverse the coordinate
   for mvt = 1:W*H
       index = listpath(mvt);
       
       indexY = mod(mvt-1,W);
       indexX = floor((mvt-1)/W);
       
       PermuteIndexY = mod(index-1, W);
       PermuteIndexX = floor((index-1)/W);

       % disp('permute')
       % disp(indexX)
       % disp(indexY)
       
       
      % disp('with')
      % disp(PermuteIndexX)
      % disp(PermuteIndexY)
       
             
       res(indexX+1, indexY+1) =   a(PermuteIndexX+1, PermuteIndexY+1);
       
      % disp(res);
      % demand = input("continue or not");
       
   end
    
   
end
     