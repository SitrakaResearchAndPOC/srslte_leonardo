function chaotic_sequence = generate_chaotique(N, type)
    % type == 1
    switch type
        case 1
            %Gingerbreadman map
             xgin(1,1)=0.5;
             ygin(1,1)=3.7;
             for k=2:N
             xgin(k,1)=1+abs(xgin(k-1,1))-ygin(k-1,1);
             ygin(k,1)=xgin(k-1,1);
             end
             x=xgin;
             y=ygin;
             
             xseq = xgin.*ygin;
             
        case 2
             %Henon map
             xhenon(1,1)=0;
             yhenon(1,1)=0.9;
             ahen=1.4; bhen=0.3; % Parameters of map
             for k=2:N
                 xhenon(k,1)=1-ahen*xhenon(k-1,1)^2+bhen*yhenon(k-1,1);
                 yhenon(k,1)=xhenon(k-1,1);
             end
             x=xhenon;
             y=yhenon;
             xseq = x.*y;
        case 3
            %Tinkerbell map
            xtin(1,1)=0;
            ytin(1,1)=0.5;
            ati=0.9; bti=-0.6; cti=2; dti=0.5;% Parameters of map

            for k=2:N
                 xtin(k,1)=xtin(k-1,1)^2-ytin(k-1,1)^2+ati*xtin(k-1,1)+bti*ytin(k-1,1);
                 ytin(k,1)=2*xtin(k-1,1)*ytin(k-1,1)+cti*xtin(k-1,1)+dti*ytin(k-1,1);
             end
             x=xtin;
             y=ytin;
             
             xseq = x.*y;
         case 4
             %Burgers' map
             xber(1,1)=-0.1;
             yber(1,1)=0.1;

             for k=2:N
                 aber=0.75; bber=1.75; % Parameters of map
                 xber(k,1)=0.75*xber(k-1,1)-yber(k-1,1)^2;
                 yber(k,1)=1.75*yber(k-1,1)+xber(k-1,1)*yber(k-1,1);
            end
             x=xber;
             y=yber;
             
             xseq = x.*y;
         case 5
            xlog(1,1)=.1;
            Alog=4; % Parameter of map

            for k=2:N
                 %Logistic map
                 xlog(k,1)=Alog*xlog(k-1,1)*(1-xlog(k-1,1));
            end
             x=xlog;
             xseq = xlog;
         case 6
             %Ricker's map
             xexp(1,1)=.1;
             Aexp=20; %Parameter of map

             for k=2:N
                 xexp(k,1)=Aexp*xexp(k-1,1)*(exp(-xexp(k-1,1)));
             end
             x=xexp;
             
             xseq = x;
         case 7
            %Initials for Cubic map
            xlogcub(1,1)=.1;
            Acub=3; % Parameter of map

             for k=2:N
                 xlogcub(k,1)= Acub*xlogcub(k-1,1)*(1-(xlogcub(k-1,1))^2);
             end
             x=xlogcub;
             
             xseq = x;

         case 8
            %Sin map
            xsin(1,1)=.1;
            Asin=1; % Parameter of map

            for k=2:N
                 xsin(k,1)=Asin*sin(pi*xsin(k-1,1));
             end
             x=xsin;
             xseq = x;
        otherwise
            disp('other value')
    end    
    chaotic_sequence = xseq';
    %chaotic_sequence=uint8(((xx-min(xx))/max(xx))*255);

end