function MSE = eqm(Iorig, Iquantif)
MSE = sum(sum((double(Iorig) -double(Iquantif)).^2))/(size(Iorig, 1)*size(Iorig,2));