function getting_key()
length_bit = 0;
while ((length_bit ~= 256) && (length_bit ~= 512))
    length_bit = input(num2str('Enter the number of bit of key : 256 or 512  : '));
end

indice_hash = 0;
disp(' ');
while ((indice_hash ~= 1) && (indice_hash ~= 2))
    disp('Please select 1 for SHA3 and 2 for SHAKE ');
    indice_hash = input(num2str('Enter the number of bit of key : 256 or 512  : '));
end

hash_type = '';
if (indice_hash == 1)
    if(length_bit == 256)
        hash_type = 'SHA3-256';
    else 
        hash_type = 'SHA3-512';        
    end
else 
    if(length_bit == 256)
        hash_type = 'SHAKE-256';
    else 
        hash_type = 'SHAKE-512';        
    end    
end

choice = 0;
disp(' ');
while((choice<1)||(choice > 8))
    disp('Please select the choice of chaotic map');
    disp(' 1 : Gingerbreadman map      2 : Henon map');
    disp(' 3 : Tinkerbell map          4 : Burgers map');
    disp(' 5 : Logistic map            6 : Ricker map');
    disp(' 7 : Cubic map               8 : Sine map');
    choice =  input(num2str('Enter choice between 1 and 8 : '));
end

matrix = imread('lena.bmp');

block_split = 135;
instability_repeat = 1;

while(true)
   index_in = input(num2str('Please enter the number of index : ')); 
   [msg, period] = split_matrix(matrix, index_in, block_split);
   % disp('msg');
   % disp(msg);
   % [A, B] = size(msg);
   %disp('hash_type');
   %disp(hash_type);
   
   hash = ANN_Chaos_SHA3_hash(choice, msg, length_bit, instability_repeat+period, hash_type);
   
   disp('hash');
   disp(hash);
   
end

end