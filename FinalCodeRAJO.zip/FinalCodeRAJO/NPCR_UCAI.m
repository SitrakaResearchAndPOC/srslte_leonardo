function [result_1,result_2]=NPCR_UCAI(img_1,img_2)
img_1=uint8(img_1);
img_2=uint8(img_2);
[m,n,k]=size(img_1);
bit_comp=(img_1~=img_2);
result_1=(sum(sum(bit_comp))/(m*n))*100;
result_2=(sum(sum(img_1-img_2))/(m*n*255))*100;
