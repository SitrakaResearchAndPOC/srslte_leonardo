function distributionHorizontal(img)
 imx = [];
 imy = [];

 [x,y, k] = size(img);
 %figure;
 for k = 1:3
    for i=1:x-1
         for j=1:y-1
             imx = [imx, img(i,j,k)];
             imy = [imy, img(i,j+1,k)];
             
         end 
    end
    
    if k == 1
        hold on;
        disp('k=1');
        scatter(imx, imy, 20, '.', 'MarkerEdgeColor', 'red');
    elseif k == 2
        hold on;
        disp('k=2');
        scatter(imx, imy, 20, '.', 'MarkerEdgeColor', 'green');
    elseif k == 3
        disp('k=3');
        hold on;
        scatter(imx, imy, 20, '.', 'MarkerEdgeColor', 'blue');
    end   
    imx = [];
    imy = [];
 end

axis([0 255 0 255])
xlabel('Valeur de (X,Y)');
ylabel('Valeur de (X,Y+1)');
title('Distribution Horizontale');

end